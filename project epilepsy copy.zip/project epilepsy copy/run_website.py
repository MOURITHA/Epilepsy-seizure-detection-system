#!/usr/bin/env python3
"""
Simple Epilepsy Prediction Website
Run this script to start the basic web application
"""

import os
import sys
from app import app

def check_model_files():
    required_files = [
        'optimized_98_model.save',
        'optimized_98_scaler.save', 
        'optimized_98_encoder.save'
    ]
    
    missing_files = []
    for file in required_files:
        if not os.path.exists(file):
            missing_files.append(file)
    
    if missing_files:
        print("❌ Missing model files:")
        for file in missing_files:
            print(f"   - {file}")
        print("\n🔧 Please run 'python optimized_98_system.py' first to create the model files.")
        return False
    
    print("✅ All model files found!")
    return True

def main():
    print("🏥 EPILEPSY PREDICTION WEBSITE")
    print("=" * 40)
    
    if not check_model_files():
        sys.exit(1)
    
    print("🚀 Starting web server...")
    print("📱 Website will be available at:")
    print("   Local:    http://localhost:5001")
    print("   Network:  http://0.0.0.0:5001")
    print("\n💡 Press Ctrl+C to stop the server")
    print("-" * 40)
    
    try:
        app.run(debug=True, host='0.0.0.0', port=5001)
    except KeyboardInterrupt:
        print("\n\n👋 Server stopped. Goodbye!")

if __name__ == '__main__':
    main()