# 🧠 Epilepsy Prediction - Sample Test Files

## 📁 Sample Files for Testing

Use these sample CSV files to test the epilepsy prediction website:

### 1. **sample_normal.csv**
- **Expected Prediction:** Normal
- **Description:** Represents normal brain activity with no seizure patterns
- **Key Features:** Low amplitude, normal frequency bands, no seizure indicators

### 2. **sample_focal_seizure.csv**
- **Expected Prediction:** Focal Seizure
- **Description:** Localized seizure activity in specific brain regions
- **Key Features:** Moderate amplitude increase, localized frequency changes

### 3. **sample_generalized_seizure.csv**
- **Expected Prediction:** Generalized Seizure
- **Description:** Widespread seizure activity affecting entire brain
- **Key Features:** High amplitude, widespread frequency changes

### 4. **sample_status_epilepticus.csv**
- **Expected Prediction:** Status Epilepticus
- **Description:** Prolonged, severe seizure requiring immediate attention
- **Key Features:** Very high amplitude, extreme frequency patterns, long duration

## 🔬 How to Test

1. **Start the website:**
   ```bash
   python run_website.py
   ```

2. **Open browser:** Go to `http://localhost:5001`

3. **Upload a sample file:** Drag and drop or click to select any sample CSV file

4. **View results:** The AI will predict the seizure type with confidence scores

## 📊 Expected Results

| Sample File | Expected Prediction | Confidence Range |
|-------------|-------------------|------------------|
| sample_normal.csv | Normal | 85-95% |
| sample_focal_seizure.csv | Focal Seizure | 80-90% |
| sample_generalized_seizure.csv | Generalized Seizure | 85-95% |
| sample_status_epilepticus.csv | Status Epilepticus | 80-90% |

## 🎯 Model Accuracy

- **Overall Accuracy:** 98.6%
- **Model Type:** Optimized Random Forest
- **Features:** 50 EEG and clinical parameters
- **Classes:** 4 (Normal, Focal, Generalized, Status)

## 💡 Tips

- Files must be in CSV format
- First row should contain feature names (headers)
- Data should contain exactly 50 features
- Use the provided samples as templates for your own data

## 🚨 Medical Disclaimer

This is a demonstration system for educational purposes. Always consult medical professionals for actual diagnosis and treatment.