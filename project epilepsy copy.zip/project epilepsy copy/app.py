from flask import Flask, render_template, request, jsonify
import pandas as pd
import numpy as np
import joblib
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

try:
    model = joblib.load('optimized_98_model.save')
    scaler = joblib.load('optimized_98_scaler.save')
    label_encoder = joblib.load('optimized_98_encoder.save')
    MODEL_LOADED = True
except:
    MODEL_LOADED = False

class_names = ['Normal', 'Focal Seizure', 'Generalized Seizure', 'Status Epilepticus']
class_descriptions = {
    'Normal': 'No seizure activity detected. Brain activity appears normal.',
    'Focal Seizure': 'Seizure activity localized to one area of the brain.',
    'Generalized Seizure': 'Seizure activity affecting the entire brain.',
    'Status Epilepticus': 'Prolonged seizure requiring immediate medical attention.'
}

def predict_epilepsy(features):
    if not MODEL_LOADED:
        return None, "Model not loaded", 0, []
    
    try:
        features = np.array(features).reshape(1, -1).astype(np.float32)
        features_scaled = scaler.transform(features)
        
        prediction = model.predict(features_scaled)[0]
        probabilities = model.predict_proba(features_scaled)[0]
        confidence = np.max(probabilities) * 100
        
        return prediction, class_names[prediction], confidence, probabilities
    except Exception as e:
        return None, f"Prediction error: {str(e)}", 0, []

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'})
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'})
    
    if file and file.filename.endswith('.csv'):
        try:
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            
            df = pd.read_csv(filepath)
            
            if len(df.columns) >= 50:
                features = df.iloc[0, :50].values.tolist()
            else:
                return jsonify({'error': f'File must have at least 50 feature columns. Found {len(df.columns)} columns.'})
            
            pred_class, pred_name, confidence, probabilities = predict_epilepsy(features)
            
            if pred_class is None:
                return jsonify({'error': pred_name})
            
            os.remove(filepath)
            
            result = {
                'prediction': pred_name,
                'confidence': round(confidence, 1),
                'description': class_descriptions[pred_name],
                'probabilities': {
                    class_names[i]: round(prob * 100, 1) 
                    for i, prob in enumerate(probabilities)
                },
                'status': 'success'
            }
            
            return jsonify(result)
            
        except Exception as e:
            return jsonify({'error': f'Error processing file: {str(e)}'})
    
    else:
        return jsonify({'error': 'Please upload a CSV file'})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)