document.addEventListener('DOMContentLoaded', function() {
    const uploadForm = document.getElementById('uploadForm');
    const fileInput = document.getElementById('fileInput');
    const fileLabel = document.querySelector('.file-input-label');
    const loading = document.getElementById('loading');
    const results = document.getElementById('results');
    const error = document.getElementById('error');

    fileInput.addEventListener('change', function() {
        if (this.files && this.files[0]) {
            const fileName = this.files[0].name;
            fileLabel.innerHTML = `<i class="fas fa-file-csv"></i> ${fileName}`;
            fileLabel.style.background = '#4CAF50';
            fileLabel.style.color = 'white';
        }
    });

    uploadForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData();
        const file = fileInput.files[0];
        
        if (!file) {
            showError('Please select a CSV file');
            return;
        }

        if (!file.name.toLowerCase().endsWith('.csv')) {
            showError('Please upload a CSV file');
            return;
        }

        formData.append('file', file);
        
        hideAllSections();
        loading.style.display = 'block';
        
        fetch('/predict', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            hideAllSections();
            
            if (data.error) {
                showError(data.error);
            } else {
                showResults(data);
            }
        })
        .catch(err => {
            hideAllSections();
            showError('Network error. Please try again.');
            console.error('Error:', err);
        });
    });

    function hideAllSections() {
        loading.style.display = 'none';
        results.style.display = 'none';
        error.style.display = 'none';
    }

    function showError(message) {
        document.getElementById('errorMessage').textContent = message;
        error.style.display = 'block';
    }

    function showResults(data) {
        document.getElementById('predictionTitle').textContent = data.prediction;
        document.getElementById('predictionDescription').textContent = data.description;
        
        const predictionIcon = document.getElementById('predictionIcon');
        predictionIcon.className = 'prediction-icon ' + getPredictionClass(data.prediction);
        
        const confidenceFill = document.getElementById('confidenceFill');
        const confidenceValue = document.getElementById('confidenceValue');
        confidenceFill.style.width = data.confidence + '%';
        confidenceValue.textContent = data.confidence + '%';
        
        if (data.confidence >= 80) {
            confidenceFill.style.background = 'linear-gradient(90deg, #4CAF50, #45a049)';
        } else if (data.confidence >= 60) {
            confidenceFill.style.background = 'linear-gradient(90deg, #FF9800, #F57C00)';
        } else {
            confidenceFill.style.background = 'linear-gradient(90deg, #F44336, #D32F2F)';
        }
        
        const probBars = document.getElementById('probBars');
        probBars.innerHTML = '';
        
        const colors = {
            'Normal': '#4CAF50',
            'Focal Seizure': '#FF9800',
            'Generalized Seizure': '#F44336',
            'Status Epilepticus': '#9C27B0'
        };
        
        Object.entries(data.probabilities).forEach(([className, probability]) => {
            const probBar = document.createElement('div');
            probBar.className = 'prob-bar';
            
            probBar.innerHTML = `
                <div class="prob-label">${className}</div>
                <div class="prob-bar-bg">
                    <div class="prob-bar-fill" style="width: ${probability}%; background: ${colors[className]}"></div>
                </div>
                <div class="prob-value">${probability}%</div>
            `;
            
            probBars.appendChild(probBar);
        });
        
        results.style.display = 'block';
        results.scrollIntoView({ behavior: 'smooth' });
    }

    function getPredictionClass(prediction) {
        switch(prediction) {
            case 'Normal': return 'normal';
            case 'Focal Seizure': return 'focal';
            case 'Generalized Seizure': return 'generalized';
            case 'Status Epilepticus': return 'status';
            default: return 'normal';
        }
    }

    // Drag and drop functionality
    const uploadCard = document.querySelector('.upload-card');
    
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        uploadCard.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    ['dragenter', 'dragover'].forEach(eventName => {
        uploadCard.addEventListener(eventName, highlight, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        uploadCard.addEventListener(eventName, unhighlight, false);
    });

    function highlight(e) {
        uploadCard.style.background = '#f0f8ff';
        uploadCard.style.borderColor = '#667eea';
    }

    function unhighlight(e) {
        uploadCard.style.background = 'white';
        uploadCard.style.borderColor = 'transparent';
    }

    uploadCard.addEventListener('drop', handleDrop, false);

    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        
        if (files.length > 0) {
            fileInput.files = files;
            const event = new Event('change', { bubbles: true });
            fileInput.dispatchEvent(event);
        }
    }
});